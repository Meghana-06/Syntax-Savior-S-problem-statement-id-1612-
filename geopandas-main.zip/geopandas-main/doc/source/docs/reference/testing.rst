=======
Testing
=======
.. currentmodule:: geopandas

GeoPandas includes specific functions to test its objects.

.. autosummary::
   :toctree: api/

   .. testing.geom_equals
   .. testing.geom_almost_equals
   testing.assert_geoseries_equal
   testing.assert_geodataframe_equal
