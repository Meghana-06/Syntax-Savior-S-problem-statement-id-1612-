The data included in this directory are copied from the `geoarrow-data` project
https://github.com/geoarrow/geoarrow-data/tree/main/example
