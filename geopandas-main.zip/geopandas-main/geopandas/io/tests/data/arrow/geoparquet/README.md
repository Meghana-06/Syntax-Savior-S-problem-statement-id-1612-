The data included in this directory are copied from the `test-data` from
https://github.com/opengeospatial/geoparquet
