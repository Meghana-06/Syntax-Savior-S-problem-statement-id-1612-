.. _cluster_examples:

Clustering
----------

Examples concerning the :mod:`sklearn.cluster` module.
