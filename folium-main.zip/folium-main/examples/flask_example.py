"""
We've updated our documentation. You can find the new version of this example here:
https://python-visualization.github.io/folium/latest/advanced_guide/flask.html
"""
