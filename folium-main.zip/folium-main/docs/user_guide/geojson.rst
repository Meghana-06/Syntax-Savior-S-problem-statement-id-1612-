GeoJSON and choropleth
--------------------------

.. toctree::
  :maxdepth: 2

  geojson/geojson
  geojson/choropleth
  geojson/geojson_marker
  geojson/geojson_popup_and_tooltip
  geojson/geopandas_and_geo_interface
  geojson/smoothing
