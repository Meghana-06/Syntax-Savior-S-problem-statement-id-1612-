Vector layers
--------------

.. toctree::
  :maxdepth: 1

  vector_layers/circle_and_circle_marker
  vector_layers/polyline
  vector_layers/rectangle
  vector_layers/polygon
  vector_layers/colorline
