# OR-Tools Bazel Build Instructions
| OS       | C++   |
|:-------- | :---: |
| Linux    | [![Status][linux_svg]][linux_link] |
| MacOS    | [![Status][macos_svg]][macos_link] |
| Windows  | [![Status][windows_svg]][windows_link] |

[linux_svg]: ./../../../actions/workflows/amd64_linux_bazel.yml/badge.svg?branch=main
[linux_link]: ./../../../actions/workflows/amd64_linux_bazel.yml
[macos_svg]: ./../../../actions/workflows/amd64_macos_bazel.yml/badge.svg?branch=main
[macos_link]: ./../../../actions/workflows/amd64_macos_bazel.yml
[windows_svg]: ./../../../actions/workflows/amd64_windows_bazel.yml/badge.svg?branch=main
[windows_link]: ./../../../actions/workflows/amd64_windows_bazel.yml

Dockers [Alpine, Archlinux, Centos, Debian, Fedora, OpenSuse, Ubuntu]: [![Status][docker_svg]][docker_link]

[docker_svg]: ./../../../actions/workflows/amd64_docker_bazel.yml/badge.svg?branch=main
[docker_link]: ./../../../actions/workflows/amd64_docker_bazel.yml

## Introduction

<nav for="bazel"> |
<a href="#requirement">Requirement</a> |
<a href="#dependencies">Dependencies</a> |
<a href="#compilation">Compilation</a> |
<a href="#testing">Testing</a> |
<a href="#integration">Integration</a> |
<a href="docs/ci.md">CI</a> |
</nav>

OR-Tools comes with a Bazel based build ([WORKSPACE](../WORKSPACE)) that can be
used on a wide range of platforms. If you don't have Bazel installed already,
you can download it for free from <https://bazel.build/>.

**warning: Currently OR-Tools Bazel doesn't support Python, Java nor .Net,
please use the Makefile or CMake based build instead.**

## Requirement

You'll need:

* `Bazel >= 5.4.0`.
* A compiler with C++17 support.

## Solvers supported

Here the list of supported solvers:

*   CP-SAT
*   GLOP
*   GLPK
*   PDLP
*   SCIP

## Dependencies

OR-Tools depends on several mandatory libraries.

*   Eigen
*   Google Abseil-cpp,
*   Google Protobuf,
*   Google Gtest,
*   Bliss,
*   SCIP,
*   GLPK (GNU Linear Programming Kit)

## Compilation

You must compile OR-Tools using at least C++17 (C++20 on windows):

*   on UNIX:

    ```sh
    bazel build -c opt --cxxopt=-std=c++17 ...
    ```

*   on Windows when using MSVC:

    ```sh
    bazel build -c opt --cxxopt="/std:c++20" ...
    ```

## Testing

You may run tests using:

*   on UNIX:

    ```sh
    bazel test -c opt --cxxopt=-std=c++17 ...
    ```

*   on Windows when using MSVC:

    ```sh
    bazel test -c opt --cxxopt="/std:c++20" ...
    ```

## Integration

To integrate OR-Tools in your own Bazel project,
you can take a look at the template project:
[or-tools/bazel\_or-tools](https://github.com/or-tools/bazel_or-tools).
