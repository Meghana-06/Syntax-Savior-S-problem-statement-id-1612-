The majority of these examples are here curtesy of Hakan Kjellerstrand.

See http://www.hakank.org/minizinc for details.

