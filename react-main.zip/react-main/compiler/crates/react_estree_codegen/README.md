# react_estree_codegen

This crate is a build dependency for `react_estree`, and contains codegen logic to produce Rust code to describe the ESTree format
given a JSON schema.