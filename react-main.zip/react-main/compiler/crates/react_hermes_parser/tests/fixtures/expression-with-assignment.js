function f() {
  let x = 1;
  return x + (x = 2) + x;
}
