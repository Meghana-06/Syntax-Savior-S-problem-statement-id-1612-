// @gating
const ErrorView = (error, _retry) => <MessageBox error={error}></MessageBox>;

export default ErrorView;
