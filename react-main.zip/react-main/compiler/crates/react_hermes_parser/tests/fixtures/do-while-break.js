function Component(props) {
  do {
    break;
  } while (props.cond);
  return props;
}
