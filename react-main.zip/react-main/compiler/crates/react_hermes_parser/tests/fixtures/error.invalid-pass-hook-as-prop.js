function Component(props) {
  return <Child foo={useFoo} />;
}
