function Component(props) {
  const x = foo[props.method](...props.a, null, ...props.b);
  return x;
}
