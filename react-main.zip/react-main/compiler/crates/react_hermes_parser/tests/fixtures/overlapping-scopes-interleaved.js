function foo(a, b) {
  let x = [];
  let y = [];
  x.push(a);
  y.push(b);
}
