function Component(x = "default", y = [{}]) {
  return [x, y];
}
