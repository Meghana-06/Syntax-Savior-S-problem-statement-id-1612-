function component(t) {
  let { a } = t;
  let y = { a };
  return y;
}
