function Component(props) {
  const x = { ...props.foo };
  return x;
}
