function Component(props) {
  let x = a?.b.c[0];
  return x;
}
