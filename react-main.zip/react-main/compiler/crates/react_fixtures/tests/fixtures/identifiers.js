// import React from "react";

// const FOO = false;

function id(x) {
  // React;
  // FOO;
  Math;
  id;
  let y = true;
  y = false;
  y;
  let z;
  z;
  return x;
}
