function Component(a) {
  Math;
  let b = 0;
  const foo = function foo_(c) {
    let d = 1;
    return a + b + c + d;
  };
  return foo();
}
