# fixtures

This crate is for tests only, and runs the suite of compiler fixture tests.